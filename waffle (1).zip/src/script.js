
let name="Hello World";
console.log(name);

const music=["rock","punk","pop"];
console.log(music);

for (let i = 0; i < music.length; i++) {
  console.log(music[i]);
}

function number(){
  let sum=0;
  for(let i=1;i<=100;i++){
    sum+=i;
  }
  return sum;

}
const result=number();
console.log(result);